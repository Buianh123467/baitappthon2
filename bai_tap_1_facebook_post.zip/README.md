# Bài Tập 1: Đăng bài tự động lên Facebook bằng Python

## Hướng dẫn sử dụng

1. Cài đặt thư viện `facebook-sdk` (chỉ cần một lần):
```bash
pip install facebook-sdk
```

2. Lấy Access Token:
- Truy cập: https://developers.facebook.com/tools/explorer/
- Tạo access token người dùng và cấp quyền `publish_to_groups`, `pages_manage_posts`, v.v.
- Dán vào file `access_token.txt`

3. Chạy chương trình:
```bash
python auto_post.py
```

## Cấu trúc thư mục

- `auto_post.py`: Mã nguồn chính
- `access_token.txt`: Dán access token vào đây
- `post_content.txt`: Nội dung bài đăng
- `README.md`: Hướng dẫn sử dụng
